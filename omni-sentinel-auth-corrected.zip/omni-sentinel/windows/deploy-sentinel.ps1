# OMNI Sentinel Windows 11 posture checks and local-only firewall baseline.
# Run elevated. This script does not disable protections or silently enable BitLocker.
[CmdletBinding(SupportsShouldProcess=$true)] param([switch]$RegisterStartupTask)
$ErrorActionPreference = 'Stop'
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  throw 'Open PowerShell as Administrator, then rerun this script.'
}
Write-Host 'OMNI Sentinel: checking Windows security posture...' -ForegroundColor Cyan
try {
  $bl = Get-BitLockerVolume -MountPoint 'C:'
  if ($bl.ProtectionStatus -ne 'On') { Write-Warning 'C: BitLocker protection is not ON. Review recovery-key backup before enabling it.' }
  else { Write-Host 'BitLocker protection: ON' }
} catch { Write-Warning "BitLocker status unavailable: $($_.Exception.Message)" }
try {
  $mp = Get-MpComputerStatus
  if (-not $mp.RealTimeProtectionEnabled) { Write-Warning 'Microsoft Defender real-time protection is OFF.' } else { Write-Host 'Defender real-time protection: ON' }
  $age = (Get-Date) - $mp.AntivirusSignatureLastUpdated
  if ($age.TotalDays -gt 3) { Write-Warning "Defender signatures are $([int]$age.TotalDays) days old." } else { Write-Host 'Defender signatures: recent' }
} catch { Write-Warning "Defender status unavailable: $($_.Exception.Message)" }
# API binds to loopback. Block inbound port 8000 at the firewall; explicit block rules override allow rules.
$ruleName = 'OMNI Sentinel API - block inbound TCP 8000'
if ($PSCmdlet.ShouldProcess($ruleName, 'Create/update Windows Firewall rule')) {
  $existing = Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
  if ($existing) { $existing | Remove-NetFirewallRule }
  New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Action Block -Protocol TCP -LocalPort 8000 -RemoteAddress Any -Profile Any | Out-Null
}
# Audit policy: enable logon and process creation auditing; verify resulting settings after deployment.
if ($PSCmdlet.ShouldProcess('Windows Advanced Audit Policy', 'Enable logon and process creation auditing')) {
  & auditpol.exe /set /subcategory:'Logon' /success:enable /failure:enable | Out-Null
  & auditpol.exe /set /subcategory:'Process Creation' /success:enable /failure:enable | Out-Null
  if ($LASTEXITCODE -ne 0) { Write-Warning 'auditpol returned a non-zero exit code; verify policy names for your Windows language.' }
}
if ($RegisterStartupTask) {
  $projectRoot = Split-Path -Parent $PSScriptRoot
  $python = (Get-Command python.exe -ErrorAction Stop).Source
  $action = New-ScheduledTaskAction -Execute $python -Argument '-m backend.main' -WorkingDirectory $projectRoot
  $trigger = New-ScheduledTaskTrigger -AtStartup
  # Intentionally run as the current user, not SYSTEM: least privilege and predictable Python environment.
  $user = [Security.Principal.WindowsIdentity]::GetCurrent().Name
  $principalTask = New-ScheduledTaskPrincipal -UserId $user -LogonType S4U -RunLevel Limited
  Register-ScheduledTask -TaskName 'OMNISentinelCoreService' -Action $action -Trigger $trigger -Principal $principalTask -Description 'OMNI Sentinel local-only API. Runs as current user with limited privileges.' -Force | Out-Null
  Write-Host 'Startup task registered for current user (limited privileges). Confirm Python environment and working directory.' -ForegroundColor Yellow
}
Write-Host 'Checks complete. No encryption or protection setting was silently changed.' -ForegroundColor Green
