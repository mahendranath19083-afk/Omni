from __future__ import annotations
import secrets, time
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from backend.config import APP_NAME, DB_PATH, HOST, PORT, TICKET_TTL_SECONDS
from backend.security.auth import require_api_key, require_loopback, approval_message, revocation_message, public_key_from_b64, verify_signature
from backend.security.store import Store

store: Store | None = None
@asynccontextmanager
async def lifespan(app: FastAPI):
    global store
    store=Store(DB_PATH)
    yield
app=FastAPI(title=APP_NAME, version='1.0.0', lifespan=lifespan)

class TicketCreate(BaseModel):
    target_action: str = Field(min_length=1, max_length=100)
    target_resource: str = Field(min_length=1, max_length=200)
    requested_by: str = Field(min_length=1, max_length=100)
    reason: str = Field(min_length=1, max_length=500)
class DeviceRegistration(BaseModel):
    public_key_der_b64: str = Field(min_length=20, max_length=2000)

class ChallengeRequest(BaseModel):
    ticket_id: str = Field(min_length=1, max_length=100)

class SignedApproval(BaseModel):
    ticket_id: str = Field(min_length=1, max_length=100)
    approved: bool = True
    challenge_id: str | None = Field(default=None, max_length=100)
    key_id: str | None = Field(default=None, max_length=64)
    signature_b64: str | None = Field(default=None, max_length=2000)

class SignedRevocation(BaseModel):
    challenge_id: str = Field(min_length=1, max_length=100)
    key_id: str = Field(min_length=1, max_length=64)
    signature_b64: str = Field(min_length=20, max_length=2000)

def get_store():
    if store is None: raise HTTPException(503, 'Store is starting')
    return store

@app.get('/health')
def health(): return {'status':'ok','system':APP_NAME,'time':int(time.time()),'binding':HOST}

@app.get('/dashboard/summary', dependencies=[Depends(require_loopback), Depends(require_api_key)])
def dashboard(s: Store=Depends(get_store)):
    from backend.security.host_posture import host_posture
    return {'device_health':host_posture(),'pending_approval_tickets':len(s.tickets()),'mode':'local-first'}

@app.get('/host/posture', dependencies=[Depends(require_loopback), Depends(require_api_key)])
def posture():
    from backend.security.host_posture import host_posture
    return host_posture()

@app.post('/auth/verify-session', dependencies=[Depends(require_loopback), Depends(require_api_key)])
def create_session(s: Store=Depends(get_store)):
    token=s.create_session()
    return {'session_token':token,'token_type':'Bearer','note':'Store this token securely; it is returned only once.'}

@app.post('/auth/register-device', dependencies=[Depends(require_loopback), Depends(require_api_key)])
def register_device(body: DeviceRegistration, s: Store=Depends(get_store)):
    _, key_id = public_key_from_b64(body.public_key_der_b64)
    s.register_device(key_id, body.public_key_der_b64)
    return {'key_id': key_id, 'registered': True}

@app.post('/auth/approval-challenge', dependencies=[Depends(require_loopback), Depends(require_api_key)])
def approval_challenge(body: ChallengeRequest, s: Store=Depends(get_store)):
    ticket = s.get_ticket(body.ticket_id)
    if not ticket: raise HTTPException(404, 'Ticket not found')
    if ticket['status'] != 'PENDING' or time.time() >= ticket['expires']:
        raise HTTPException(409, 'Ticket is not pending or has expired')
    return s.create_challenge('approve', body.ticket_id, 90)

@app.post('/auth/revocation-challenge', dependencies=[Depends(require_loopback), Depends(require_api_key)])
def revocation_challenge(s: Store=Depends(get_store)):
    return s.create_challenge('revoke_all_sessions', '', 90)

@app.post('/auth/revoke-all-sessions', dependencies=[Depends(require_loopback), Depends(require_api_key)])
def revoke(body: SignedRevocation, s: Store=Depends(get_store)):
    device = s.get_device(body.key_id)
    if not device: raise HTTPException(403, 'Device key is not registered or has been revoked')
    challenge = s.consume_challenge(body.challenge_id, 'revoke_all_sessions')
    if not challenge: raise HTTPException(409, 'Challenge is invalid, expired, or already used')
    message = revocation_message(body.challenge_id, challenge['nonce'], int(challenge['expires']))
    verified_key_id = verify_signature(device['public_key_der_b64'], message, body.signature_b64)
    if verified_key_id != body.key_id: raise HTTPException(403, 'Device key mismatch')
    s.revoke_all()
    return {'revoked':True, 'device_keys_revoked':True}

@app.post('/tickets', dependencies=[Depends(require_loopback), Depends(require_api_key)])
def create_ticket(body: TicketCreate, s: Store=Depends(get_store)):
    t=s.create_ticket(body.target_action,body.target_resource,body.requested_by,body.reason,TICKET_TTL_SECONDS)
    return t

@app.get('/tickets', dependencies=[Depends(require_loopback), Depends(require_api_key)])
def list_tickets(s: Store=Depends(get_store)): return {'tickets':s.tickets()}

@app.post('/iphone/resolve-ticket', dependencies=[Depends(require_loopback), Depends(require_api_key)])
def resolve_ticket(body: SignedApproval, s: Store=Depends(get_store)):
    ticket=s.get_ticket(body.ticket_id)
    if not ticket: raise HTTPException(404,'Ticket not found')
    if ticket['status'] != 'PENDING' or time.time() >= ticket['expires']:
        raise HTTPException(409, 'Ticket is not pending or has expired')
    if body.approved:
        if not body.challenge_id or not body.key_id or not body.signature_b64:
            raise HTTPException(403, 'Signed biometric-bound approval is required')
        device=s.get_device(body.key_id)
        if not device: raise HTTPException(403, 'Device key is not registered or has been revoked')
        challenge=s.consume_challenge(body.challenge_id, 'approve', body.ticket_id)
        if not challenge: raise HTTPException(409, 'Challenge is invalid, expired, or already used')
        message=approval_message(body.ticket_id, body.challenge_id, challenge['nonce'], int(challenge['expires']))
        verified_key_id=verify_signature(device['public_key_der_b64'], message, body.signature_b64)
        if verified_key_id != body.key_id: raise HTTPException(403, 'Device key mismatch')
    result=s.resolve_ticket(body.ticket_id, body.approved)
    if result in ('EXPIRED','ALREADY_RESOLVED'): raise HTTPException(409, result)
    if result=='NOT_FOUND': raise HTTPException(404, 'Ticket not found')
    return {'ticket_id':body.ticket_id,'status':result}

@app.get('/agent/tools', dependencies=[Depends(require_loopback), Depends(require_api_key)])
def tools():
    from backend.agent.tools import ALLOWED_READ_ONLY_TOOLS
    return {'allowlist':sorted(ALLOWED_READ_ONLY_TOOLS),'default':'deny','remote_execution':False}

if __name__=='__main__':
    import uvicorn
    uvicorn.run('backend.main:app',host=HOST,port=PORT,reload=False)
