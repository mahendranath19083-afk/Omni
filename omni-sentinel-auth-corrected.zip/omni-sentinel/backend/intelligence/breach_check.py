"""Privacy-first placeholder: no breach lookup occurs without an explicitly configured, authorized provider."""
def lookup_breach_status(identifier: str, provider=None):
    if provider is None:
        return {'status':'not_configured','queried':False,'message':'No external breach service was contacted.'}
    return provider.lookup(identifier)
