"""RSS URL policy helpers. Fetching is intentionally not automatic; callers must choose trusted feeds."""
from urllib.parse import urlparse
ALLOWED_SCHEMES={'https'}
def validate_feed_url(url: str) -> str:
    p=urlparse(url)
    if p.scheme not in ALLOWED_SCHEMES or not p.hostname or p.username or p.password:
        raise ValueError('Feed must be an HTTPS URL without embedded credentials')
    return url
