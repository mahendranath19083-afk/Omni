"""OMNI Sentinel backend package."""
