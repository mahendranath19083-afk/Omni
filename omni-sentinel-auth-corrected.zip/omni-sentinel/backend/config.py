from __future__ import annotations
import os
from pathlib import Path

APP_NAME = "OMNI Sentinel"
HOST = os.getenv("SENTINEL_HOST", "127.0.0.1")
PORT = int(os.getenv("SENTINEL_PORT", "8000"))
DATA_DIR = Path(os.getenv("SENTINEL_DATA_DIR", str(Path.home() / ".omni-sentinel"))).expanduser()
DB_PATH = DATA_DIR / "sentinel.sqlite3"
API_KEY = os.getenv("SENTINEL_API_KEY", "")
TICKET_TTL_SECONDS = 120
ALLOW_REMOTE_BIND = os.getenv("SENTINEL_ALLOW_REMOTE_BIND", "false").lower() == "true"
if HOST not in ("127.0.0.1", "::1", "localhost") and not ALLOW_REMOTE_BIND:
    raise RuntimeError("Remote binding is disabled. Use loopback or explicitly configure a secured deployment.")
