from __future__ import annotations

import base64
import hashlib
import hmac
import time
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from fastapi import Header, HTTPException, Request

from backend.config import API_KEY


def require_api_key(x_sentinel_api_key: str | None = Header(default=None)) -> None:
    if not API_KEY or not x_sentinel_api_key or not hmac.compare_digest(API_KEY, x_sentinel_api_key):
        raise HTTPException(status_code=401, detail="Valid Sentinel API key required")


def require_loopback(request: Request) -> None:
    host = request.client.host if request.client else ""
    if host not in ("127.0.0.1", "::1", "localhost", "testclient"):
        raise HTTPException(status_code=403, detail="Loopback clients only")


def approval_message(ticket_id: str, challenge_id: str, nonce: str, expires: int) -> bytes:
    """Canonical, versioned bytes both Python and Swift sign; never sign client booleans."""
    return f"OMNI-SENTINEL-V1\nAPPROVE\n{ticket_id}\n{challenge_id}\n{nonce}\n{expires}".encode("utf-8")


def revocation_message(challenge_id: str, nonce: str, expires: int) -> bytes:
    return f"OMNI-SENTINEL-V1\nREVOKE_ALL_SESSIONS\n{challenge_id}\n{nonce}\n{expires}".encode("utf-8")


def public_key_from_b64(der_b64: str):
    try:
        der = base64.b64decode(der_b64, validate=True)
        key = serialization.load_der_public_key(der)
    except Exception as exc:
        raise HTTPException(status_code=422, detail="Invalid DER public key") from exc
    if not isinstance(key, ec.EllipticCurvePublicKey) or not isinstance(key.curve, ec.SECP256R1):
        raise HTTPException(status_code=422, detail="Public key must be ECDSA P-256")
    return key, hashlib.sha256(der).hexdigest()[:32]


def verify_signature(public_key_der_b64: str, message: bytes, signature_b64: str) -> str:
    key, key_id = public_key_from_b64(public_key_der_b64)
    try:
        signature = base64.b64decode(signature_b64, validate=True)
        key.verify(signature, message, ec.ECDSA(hashes.SHA256()))
    except (ValueError, InvalidSignature) as exc:
        raise HTTPException(status_code=403, detail="Biometric-bound device signature rejected") from exc
    return key_id
