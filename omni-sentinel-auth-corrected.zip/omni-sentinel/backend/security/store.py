from __future__ import annotations
import hashlib, hmac, os, secrets, sqlite3, time
from pathlib import Path
from typing import Any

class Store:
    """Small SQLite store. Secrets are never written to logs; tickets expire server-side."""
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        try: os.chmod(path.parent, 0o700)
        except OSError: pass
        self.path = path
        with self.connect() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, created REAL NOT NULL, revoked INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS tickets (id TEXT PRIMARY KEY, action TEXT NOT NULL, resource TEXT NOT NULL, requested_by TEXT NOT NULL, reason TEXT NOT NULL, created REAL NOT NULL, expires REAL NOT NULL, status TEXT NOT NULL DEFAULT 'PENDING');
            CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, event TEXT NOT NULL, details TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS devices (key_id TEXT PRIMARY KEY, public_key_der_b64 TEXT NOT NULL, created REAL NOT NULL, revoked INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS challenges (id TEXT PRIMARY KEY, purpose TEXT NOT NULL, ticket_id TEXT NOT NULL DEFAULT '', nonce TEXT NOT NULL, expires REAL NOT NULL, used INTEGER NOT NULL DEFAULT 0);
            ''')
        try: os.chmod(path, 0o600)
        except OSError: pass
    def connect(self):
        db = sqlite3.connect(self.path, timeout=5)
        db.row_factory = sqlite3.Row
        return db
    @staticmethod
    def hash_token(token: str) -> str: return hashlib.sha256(token.encode()).hexdigest()
    def audit(self, event: str, details: str = ""):
        with self.connect() as db: db.execute('INSERT INTO audit(ts,event,details) VALUES(?,?,?)',(time.time(),event,details[:500]))

    def register_device(self, key_id: str, public_key_der_b64: str):
        with self.connect() as db:
            db.execute('INSERT INTO devices(key_id,public_key_der_b64,created,revoked) VALUES(?,?,?,0) ON CONFLICT(key_id) DO UPDATE SET public_key_der_b64=excluded.public_key_der_b64,revoked=0', (key_id, public_key_der_b64, time.time()))
        self.audit('device_key_registered', key_id)

    def get_device(self, key_id: str):
        with self.connect() as db:
            row = db.execute('SELECT * FROM devices WHERE key_id=? AND revoked=0', (key_id,)).fetchone()
        return dict(row) if row else None

    def create_challenge(self, purpose: str, ticket_id: str = '', ttl: int = 90):
        now = time.time(); challenge_id = secrets.token_urlsafe(18); nonce = secrets.token_urlsafe(32); expires = int(now + ttl)
        with self.connect() as db:
            db.execute('INSERT INTO challenges(id,purpose,ticket_id,nonce,expires) VALUES(?,?,?,?,?)', (challenge_id, purpose, ticket_id, nonce, expires))
        return {'challenge_id': challenge_id, 'purpose': purpose, 'ticket_id': ticket_id or None, 'nonce': nonce, 'expires': expires}

    def consume_challenge(self, challenge_id: str, purpose: str, ticket_id: str = ''):
        now = time.time()
        with self.connect() as db:
            row = db.execute('SELECT * FROM challenges WHERE id=?', (challenge_id,)).fetchone()
            if not row or row['purpose'] != purpose or row['ticket_id'] != ticket_id or row['used'] or now > row['expires']:
                return None
            changed = db.execute('UPDATE challenges SET used=1 WHERE id=? AND used=0', (challenge_id,)).rowcount
            if changed != 1: return None
        return dict(row)

    def revoke_devices(self):
        with self.connect() as db: db.execute('UPDATE devices SET revoked=1 WHERE revoked=0')
        self.audit('all_device_keys_revoked')

    def create_session(self):
        token = secrets.token_urlsafe(32)
        with self.connect() as db: db.execute('INSERT INTO sessions(token_hash,created) VALUES(?,?)',(self.hash_token(token),time.time()))
        self.audit('session_created')
        return token
    def valid_session(self, token: str):
        with self.connect() as db: row=db.execute('SELECT revoked FROM sessions WHERE token_hash=?',(self.hash_token(token),)).fetchone()
        return bool(row and not row['revoked'])
    def revoke_all(self):
        with self.connect() as db: db.execute('UPDATE sessions SET revoked=1 WHERE revoked=0')
        self.audit('all_sessions_revoked')
    def create_ticket(self, action: str, resource: str, requested_by: str, reason: str, ttl: int):
        now=time.time(); ticket_id=secrets.token_urlsafe(18)
        with self.connect() as db: db.execute('INSERT INTO tickets(id,action,resource,requested_by,reason,created,expires) VALUES(?,?,?,?,?,?,?)',(ticket_id,action,resource,requested_by,reason,now,now+ttl))
        self.audit('ticket_created', ticket_id)
        return self.get_ticket(ticket_id)
    def get_ticket(self, ticket_id: str):
        with self.connect() as db: row=db.execute('SELECT * FROM tickets WHERE id=?',(ticket_id,)).fetchone()
        if not row: return None
        d=dict(row); d['ticket_id']=d.pop('id'); return d
    def tickets(self):
        with self.connect() as db: rows=db.execute("SELECT * FROM tickets WHERE status='PENDING' ORDER BY created DESC").fetchall()
        out=[]
        for row in rows:
            d=dict(row); d['ticket_id']=d.pop('id'); out.append(d)
        return out
    def resolve_ticket(self, ticket_id: str, approved: bool):
        now=time.time()
        with self.connect() as db:
            row=db.execute('SELECT * FROM tickets WHERE id=?',(ticket_id,)).fetchone()
            if not row: return 'NOT_FOUND'
            if row['status']!='PENDING': return 'ALREADY_RESOLVED'
            if now > row['expires']:
                db.execute("UPDATE tickets SET status='EXPIRED' WHERE id=?",(ticket_id,)); return 'EXPIRED'
            status='APPROVED' if approved else 'DENIED'
            db.execute('UPDATE tickets SET status=? WHERE id=?',(status,ticket_id))
        self.audit('ticket_'+status.lower(), ticket_id)
        return status
