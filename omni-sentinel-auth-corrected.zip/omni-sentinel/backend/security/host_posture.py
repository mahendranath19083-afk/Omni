from __future__ import annotations
import platform, subprocess

def _powershell(command: str):
    try:
        p=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',command],capture_output=True,text=True,timeout=8,check=False)
        if p.returncode != 0: return None
        return p.stdout.strip()
    except (OSError, subprocess.TimeoutExpired): return None

def host_posture():
    if platform.system() != 'Windows':
        return {'platform': platform.platform(), 'bitlocker': 'not_applicable', 'defender_realtime': 'not_applicable', 'signature_age_days': None, 'note':'Windows-only checks are not available on this host.'}
    bitlocker=_powershell("(Get-BitLockerVolume -MountPoint 'C:' -ErrorAction Stop).ProtectionStatus")
    defender=_powershell("(Get-MpComputerStatus -ErrorAction Stop).RealTimeProtectionEnabled")
    sig=_powershell("(Get-MpComputerStatus -ErrorAction Stop).AntivirusSignatureLastUpdated.ToString('o')")
    return {'platform': platform.platform(), 'bitlocker': {'0':'off','1':'on'}.get(bitlocker, 'unknown'), 'defender_realtime': {'True':'on','False':'off'}.get(defender, 'unknown'), 'signature_last_updated':sig, 'note':'Status is observational; unknown means the query failed or permissions are insufficient.'}
