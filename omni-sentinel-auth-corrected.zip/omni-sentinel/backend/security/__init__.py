"""Security controls for OMNI Sentinel."""
