"""Explicit allowlist for agent actions. Unknown actions are always denied."""
ALLOWED_READ_ONLY_TOOLS = frozenset({'health_summary', 'host_posture', 'pending_tickets'})

def authorize_tool(tool_name: str) -> bool:
    return tool_name in ALLOWED_READ_ONLY_TOOLS

def dispatch_read_only(tool_name: str, context: dict):
    if not authorize_tool(tool_name):
        raise PermissionError(f'Tool not allowlisted: {tool_name}')
    if tool_name == 'health_summary': return {'service':'OMNI Sentinel','mode':'local-first','privileged_actions':'approval_required'}
    if tool_name == 'host_posture':
        from backend.security.host_posture import host_posture
        return host_posture()
    if tool_name == 'pending_tickets': return context['store'].tickets()
    raise PermissionError('Tool not implemented')
