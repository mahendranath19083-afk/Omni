import os, tempfile, time, base64, hashlib
from pathlib import Path
from fastapi.testclient import TestClient
os.environ['SENTINEL_API_KEY']='test-key-not-for-production'
os.environ['SENTINEL_DATA_DIR']=tempfile.mkdtemp(prefix='sentinel-test-')
from backend import config
# Main reads config constants at import; store is created by app lifespan.
from backend.main import app
from backend.security.store import Store
from backend.security.auth import approval_message, revocation_message
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization
from backend.agent.tools import authorize_tool
from backend.intelligence.rss_parser import validate_feed_url

client=TestClient(app)
client.__enter__()  # start app lifespan so the test database is initialized

def headers(): return {'X-Sentinel-API-Key':'test-key-not-for-production'}
def test_01_health():
    r=client.get('/health'); assert r.status_code==200 and r.json()['status']=='ok'
def test_02_host_posture_endpoint_auth():
    assert client.get('/host/posture').status_code==401
    assert client.get('/host/posture',headers=headers()).status_code==200
def test_03_allowlist_default_deny():
    assert authorize_tool('health_summary') and not authorize_tool('run_powershell')
def test_04_ticket_creation_and_expiry():
    s=Store(Path(tempfile.mkdtemp())/'x.db'); t=s.create_ticket('view_status','workstation','test','test ticket',1)
    assert t['status']=='PENDING' and t['expires']>t['created']
    time.sleep(1.05); assert s.resolve_ticket(t['ticket_id'],True)=='EXPIRED'
def register_test_device():
    private_key = ec.generate_private_key(ec.SECP256R1())
    public_der = private_key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    public_b64 = base64.b64encode(public_der).decode()
    key_id = hashlib.sha256(public_der).hexdigest()[:32]
    r = client.post('/auth/register-device', headers=headers(), json={'public_key_der_b64': public_b64})
    assert r.status_code == 200 and r.json()['key_id'] == key_id
    return private_key, key_id

def test_05_client_boolean_cannot_approve():
    r=client.post('/tickets',headers=headers(),json={'target_action':'view_status','target_resource':'pc','requested_by':'test','reason':'test'})
    ticket_id = r.json()['ticket_id']
    r=client.post('/iphone/resolve-ticket',headers=headers(),json={'ticket_id':ticket_id,'approved':True,'biometric_verified':True})
    assert r.status_code == 403

def test_06_signed_challenge_approves_ticket():
    private_key, key_id = register_test_device()
    ticket = client.post('/tickets',headers=headers(),json={'target_action':'view_status','target_resource':'pc','requested_by':'test','reason':'test'}).json()
    challenge = client.post('/auth/approval-challenge',headers=headers(),json={'ticket_id':ticket['ticket_id']}).json()
    message = approval_message(ticket['ticket_id'], challenge['challenge_id'], challenge['nonce'], challenge['expires'])
    signature = private_key.sign(message, ec.ECDSA(__import__('cryptography').hazmat.primitives.hashes.SHA256()))
    result = client.post('/iphone/resolve-ticket',headers=headers(),json={'ticket_id':ticket['ticket_id'],'approved':True,'challenge_id':challenge['challenge_id'],'key_id':key_id,'signature_b64':base64.b64encode(signature).decode()})
    assert result.status_code == 200 and result.json()['status'] == 'APPROVED'
    replay = client.post('/iphone/resolve-ticket',headers=headers(),json={'ticket_id':ticket['ticket_id'],'approved':True,'challenge_id':challenge['challenge_id'],'key_id':key_id,'signature_b64':base64.b64encode(signature).decode()})
    assert replay.status_code in (409, 403)

def test_07_denial_does_not_require_biometrics():
    r=client.post('/tickets',headers=headers(),json={'target_action':'view_status','target_resource':'pc','requested_by':'test','reason':'test'})
    q=client.post('/iphone/resolve-ticket',headers=headers(),json={'ticket_id':r.json()['ticket_id'],'approved':False})
    assert q.status_code==200 and q.json()['status']=='DENIED'

def test_07b_signed_emergency_revocation():
    private_key, key_id = register_test_device()
    challenge = client.post('/auth/revocation-challenge',headers=headers(),json={}).json()
    message = revocation_message(challenge['challenge_id'], challenge['nonce'], challenge['expires'])
    from cryptography.hazmat.primitives import hashes
    signature = private_key.sign(message, ec.ECDSA(hashes.SHA256()))
    result = client.post('/auth/revoke-all-sessions',headers=headers(),json={'challenge_id':challenge['challenge_id'],'key_id':key_id,'signature_b64':base64.b64encode(signature).decode()})
    assert result.status_code == 200 and result.json()['revoked'] is True

def test_08_feed_requires_https():
    assert validate_feed_url('https://www.cisa.gov/')
    try: validate_feed_url('http://example.com/feed'); assert False
    except ValueError: pass
def test_09_tools_endpoint_is_allowlisted():
    r=client.get('/agent/tools',headers=headers()); assert r.status_code==200 and r.json()['default']=='deny'
