import Foundation
import LocalAuthentication
import Security
import Combine
import CryptoKit

public struct ApprovalTicket: Codable, Identifiable {
    public let id: String
    public let targetAction: String
    public let targetResource: String
    public let requestedBy: String
    public let createdAt: Double
    public let expiresAt: Double
    public let status: String
    public let reason: String
    enum CodingKeys: String, CodingKey {
        case id = "ticket_id", targetAction = "action", targetResource = "resource"
        case requestedBy = "requested_by", createdAt = "created", expiresAt = "expires", status, reason
    }
    public var isExpired: Bool { Date().timeIntervalSince1970 >= expiresAt }
}

private struct ChallengeResponse: Decodable {
    let challenge_id: String
    let purpose: String
    let ticket_id: String?
    let nonce: String
    let expires: Int
}

private struct DeviceRegistrationResponse: Decodable { let key_id: String; let registered: Bool }
private struct TicketResolutionResponse: Decodable { let ticket_id: String; let status: String }

public enum SentinelError: LocalizedError {
    case invalidURL, missingAPIKey, invalidResponse, httpStatus(Int), serverRejected(String), biometricUnavailable
    public var errorDescription: String? {
        switch self {
        case .invalidURL: return "Invalid Sentinel server URL."
        case .missingAPIKey: return "Sentinel API key is not stored in Keychain."
        case .invalidResponse: return "Invalid server response."
        case .httpStatus(let code): return "Sentinel server returned HTTP \(code)."
        case .serverRejected(let message): return message
        case .biometricUnavailable: return "Face ID is unavailable on this device."
        }
    }
}

@MainActor public final class SentinelCompanionManager: ObservableObject {
    public static let shared = SentinelCompanionManager()
    @Published public private(set) var isConnected = false

    private let baseURL: URL
    private let service = "com.omni.sentinel.companion"
    private let apiKeyAccount = "sentinel_admin_key"
    private let signingKeyAccount = "sentinel_p256_private_key"
    private let session: URLSession

    /// On iPhone, 127.0.0.1 means the phone itself. Pass the workstation's reachable HTTPS URL.
    /// Plain HTTP is accepted only for localhost development; do not expose it on a network.
    public init(baseURL: URL, session: URLSession = .shared) {
        self.baseURL = baseURL
        self.session = session
    }

    public func saveAPIKey(_ key: String) throws {
        guard let data = key.data(using: .utf8), !key.isEmpty else { throw SentinelError.missingAPIKey }
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service, kSecAttrAccount as String: apiKeyAccount]
        let update: [String: Any] = [kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
        let status = SecItemUpdate(query as CFDictionary, update as CFDictionary)
        if status == errSecItemNotFound {
            var add = query; update.forEach { add[$0.key] = $0.value }
            let addStatus = SecItemAdd(add as CFDictionary, nil)
            guard addStatus == errSecSuccess else { throw NSError(domain: NSOSStatusErrorDomain, code: Int(addStatus)) }
        } else if status != errSecSuccess { throw NSError(domain: NSOSStatusErrorDomain, code: Int(status)) }
    }

    private func apiKey() throws -> String {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service, kSecAttrAccount as String: apiKeyAccount,
            kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status == errSecSuccess, let data = item as? Data,
              let key = String(data: data, encoding: .utf8), !key.isEmpty else { throw SentinelError.missingAPIKey }
        return key
    }

    private func request(path: String, method: String = "POST", body: [String: Any]? = nil) async throws -> Data {
        guard let url = URL(string: path, relativeTo: baseURL),
              let scheme = url.scheme?.lowercased(),
              scheme == "https" || (scheme == "http" && ["127.0.0.1", "localhost", "::1"].contains(url.host ?? "")) else {
            throw SentinelError.invalidURL
        }
        var req = URLRequest(url: url); req.httpMethod = method
        req.setValue(try apiKey(), forHTTPHeaderField: "X-Sentinel-API-Key")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        if let body {
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            req.httpBody = try JSONSerialization.data(withJSONObject: body)
        }
        let (data, response) = try await session.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw SentinelError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            let message = String(data: data, encoding: .utf8) ?? "Request rejected"
            throw SentinelError.serverRejected("HTTP \(http.statusCode): \(message.prefix(250))")
        }
        isConnected = true
        return data
    }

    /// Generates a P-256 signing key stored in the iOS Keychain. Reading the private key requires
    /// the current biometric set; the server stores only the public key. Call once per device.
    public func registerBiometricDeviceKey() async throws {
        let access = SecAccessControlCreateWithFlags(nil, kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
                                                     .biometryCurrentSet, nil)
        guard let access else { throw SentinelError.biometricUnavailable }
        let privateKey = P256.Signing.PrivateKey()
        let keyData = privateKey.rawRepresentation
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service, kSecAttrAccount as String: signingKeyAccount]
        SecItemDelete(query as CFDictionary)
        var add = query
        add[kSecValueData as String] = keyData
        add[kSecAttrAccessControl as String] = access
        let status = SecItemAdd(add as CFDictionary, nil)
        guard status == errSecSuccess else { throw NSError(domain: NSOSStatusErrorDomain, code: Int(status)) }

        let publicDER = privateKey.publicKey.derRepresentation
        let keyID = SHA256.hash(data: publicDER).map { String(format: "%02x", $0) }.joined().prefix(32)
        let body: [String: Any] = ["public_key_der_b64": publicDER.base64EncodedString()]
        let data = try await request(path: "/auth/register-device", body: body)
        let response = try JSONDecoder().decode(DeviceRegistrationResponse.self, from: data)
        guard response.registered, response.key_id == String(keyID) else {
            throw SentinelError.serverRejected("The server returned a different device-key identity.")
        }
        UserDefaults.standard.set(response.key_id, forKey: "omni.sentinel.device_key_id")
    }

    /// Keychain access prompts for Face ID. The server verifies the signature, not a client boolean.
    private func signWithBiometricKey(message: Data, reason: String) throws -> Data {
        let context = LAContext()
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service, kSecAttrAccount as String: signingKeyAccount,
            kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne,
            kSecUseAuthenticationContext as String: context,
            kSecUseOperationPrompt as String: reason]
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status == errSecSuccess, let raw = item as? Data else {
            if status == errSecUserCanceled || status == errSecAuthFailed { throw SentinelError.serverRejected("Face ID authentication was cancelled or failed.") }
            throw NSError(domain: NSOSStatusErrorDomain, code: Int(status))
        }
        let privateKey = try P256.Signing.PrivateKey(rawRepresentation: raw)
        return try privateKey.signature(for: message).derRepresentation
    }

    private func approvalMessage(ticketID: String, challenge: ChallengeResponse) -> Data {
        Data("OMNI-SENTINEL-V1\nAPPROVE\n\(ticketID)\n\(challenge.challenge_id)\n\(challenge.nonce)\n\(challenge.expires)".utf8)
    }
    private func revocationMessage(challenge: ChallengeResponse) -> Data {
        Data("OMNI-SENTINEL-V1\nREVOKE_ALL_SESSIONS\n\(challenge.challenge_id)\n\(challenge.nonce)\n\(challenge.expires)".utf8)
    }
    private func keyIDForStoredKey() throws -> String {
        guard let keyID = UserDefaults.standard.string(forKey: "omni.sentinel.device_key_id"), !keyID.isEmpty else {
            throw SentinelError.serverRejected("Register the biometric device key first.")
        }
        return keyID
    }

    public func resolveTicket(ticketID: String, approve: Bool) async throws -> String {
        guard !ticketID.isEmpty else { throw SentinelError.serverRejected("Ticket ID is required.") }
        var body: [String: Any] = ["ticket_id": ticketID, "approved": approve]
        if approve {
            let challengeData = try await request(path: "/auth/approval-challenge", body: ["ticket_id": ticketID])
            let challenge = try JSONDecoder().decode(ChallengeResponse.self, from: challengeData)
            let signature = try signWithBiometricKey(message: approvalMessage(ticketID: ticketID, challenge: challenge),
                reason: "Use Face ID to approve this specific OMNI Sentinel request")
            body["challenge_id"] = challenge.challenge_id
            body["key_id"] = try keyIDForStoredKey()
            body["signature_b64"] = signature.base64EncodedString()
        }
        let data = try await request(path: "/iphone/resolve-ticket", body: body)
        return try JSONDecoder().decode(TicketResolutionResponse.self, from: data).status
    }

    public func emergencyRevokeAllSessions() async throws {
        let challengeData = try await request(path: "/auth/revocation-challenge", body: [:])
        let challenge = try JSONDecoder().decode(ChallengeResponse.self, from: challengeData)
        let signature = try signWithBiometricKey(message: revocationMessage(challenge: challenge),
            reason: "Use Face ID to confirm emergency revocation of all Sentinel sessions")
        let body: [String: Any] = ["challenge_id": challenge.challenge_id,
            "key_id": try keyIDForStoredKey(), "signature_b64": signature.base64EncodedString()]
        _ = try await request(path: "/auth/revoke-all-sessions", body: body)
    }
}
