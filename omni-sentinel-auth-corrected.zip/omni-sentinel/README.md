# OMNI Sentinel — local-first security companion

Starter implementation for a Windows 11 security posture monitor, loopback-only FastAPI service, approval-ticket workflow, and Swift iOS companion framework. It is deliberately **deny-by-default**: no arbitrary shell execution, remote tracking, covert capture, or autonomous privileged actions are implemented.

## What's included

- `windows/deploy-sentinel.ps1` — admin check; BitLocker/Defender posture audit; firewall baseline for TCP 8000; logon and process-creation auditing; optional limited-user startup task.
- `backend/` — API-key-protected local API, SQLite audit/ticket store, 120-second approval expiry, approval biometric assertion requirement, session revocation endpoint, read-only tool allowlist, Windows posture probes.
- `ios/SentinelCompanion/SentinelCompanion.swift` — Keychain storage, LocalAuthentication gate, ticket resolution, and emergency session revocation with HTTP status validation.
- `tests/test_suite.py` — nine focused verification tests.
- `docs/` — architecture and certification boundaries.

## Local setup (Windows 11)

1. Install Python 3.11 or newer.
2. In PowerShell, from this directory:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
$env:SENTINEL_API_KEY = [Convert]::ToBase64String([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
```

Keep the API key private. Do not put it in source control or screenshots. Then start the service:

```powershell
python -m backend.main
```

In another terminal with the same key:

```powershell
$headers = @{ 'X-Sentinel-API-Key' = $env:SENTINEL_API_KEY }
Invoke-RestMethod http://127.0.0.1:8000/health
Invoke-RestMethod -Headers $headers http://127.0.0.1:8000/dashboard/summary
```

`/health` is intentionally unauthenticated and reveals only basic service status. All privileged/host-detail endpoints require the API key and loopback client. The service binds to `127.0.0.1` by default.

## Windows hardening

Review the script before running it, then:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned
.\windows\deploy-sentinel.ps1 -WhatIf
.\windows\deploy-sentinel.ps1
```

The script reports BitLocker and Defender status; it does **not** silently enable encryption, alter recovery-key handling, or disable protections. Firewall and audit policy changes affect the machine. For an optional startup task, use `-RegisterStartupTask`; it runs as the current user with limited privileges rather than SYSTEM. Verify the Python executable and project path before enabling it.

## Tests

```powershell
python -m pip install -r requirements.txt
python -m pytest -q
```

The suite covers health, authentication, allowlist behavior, expiry, approval gating, denial, revocation route, HTTPS feed validation, and tool listing. Tests are not proof of security or a formal certification. Run on a supported machine and inspect actual output before describing any suite as passing.

## iPhone integration notes

The default URL `http://127.0.0.1:8000` refers to the iPhone itself when used on iOS. It does **not** reach a Windows PC. For a companion connection, configure a trusted HTTPS URL through a secure VPN/private network or an authenticated gateway. Do not expose port 8000 directly to the internet. The API currently restricts requests to loopback, so remote companion access requires a deliberately designed gateway/proxy and a reviewed remote-authentication model; simply changing the bind address is not sufficient.

The `biometric_verified` JSON field is a client assertion, not cryptographic proof to the server that Face ID succeeded. Production approval must bind a server nonce and ticket scope to a hardware-backed, cryptographically verifiable device credential (for example, App Attest / a suitable challenge-signature design). Do not use this starter's boolean alone for high-impact workstation elevation.

## Current limitations

- FIDO2/WebAuthn and cryptographically verifiable iPhone attestation are not yet implemented.
- Session tokens are stored hashed and revocable, but no full bearer-token middleware is wired into every route yet; API key is the current route gate.
- RSS feed parsing/fetching and breach lookups are policy scaffolds only; no external requests are made.
- No remote camera/microphone access, GPS tracking, or unattended workstation control is implemented.
- Windows event-log collection and service installation need machine-specific review.
- No NIST, FIPS, government, or independent security certification is claimed.


## Biometric approval protocol (prototype)

Approval no longer trusts a client-supplied `biometric_verified` boolean. The iOS companion creates a P-256 signing key whose private key is stored in Keychain with `biometryCurrentSet` access control. The server stores only the public key. For an approval or emergency revocation, the client requests a short-lived one-time challenge, accesses the protected key (triggering Face ID), and signs a canonical, purpose-bound message. The server verifies the ECDSA signature and consumes the challenge once. Ticket denial does not require Face ID.

### First-time iOS enrollment
1. Configure a strong `SENTINEL_API_KEY` on the workstation and store it in the app's Keychain.
2. Configure the app with the workstation's reachable **HTTPS** base URL. `127.0.0.1` on an iPhone points to the phone, not the workstation.
3. Call `registerBiometricDeviceKey()` once from the app's setup flow. It creates a new biometric-protected key and registers its public key with the local server.
4. The iOS signing key is bound to the current biometric enrollment. If Face ID is reset or the signing key is deleted, enroll again.

### Important security boundaries
- This is a prototype protocol, not a production-reviewed authentication system. Have the Swift app compiled and tested on a physical iPhone before deployment.
- The API key is still a bootstrap credential for the local API; emergency revocation revokes server-issued sessions, not the static API key. Rotate `SENTINEL_API_KEY` separately if it may be compromised.
- The backend defaults to loopback-only binding. Do not expose it directly to the public internet; remote use requires a hardened TLS/private-network deployment.
- The server signature proves possession of the enrolled private key. The key's Keychain access policy prompts for Face ID, but the server does not receive raw biometric data and cannot independently inspect Face ID itself.
