# Certification and compliance boundaries

- **NIST CSF 2.0 alignment:** The controls may support discussion of asset protection, data security, and security monitoring. A script or mapping does not establish organizational conformance or certification.
- **NIST SP 800-63B:** Naming an authentication design after this publication does not prove an Authentication Assurance Level. AAL claims require the full applicable authenticator, lifecycle, verifier, replay resistance, and binding requirements to be met and assessed.
- **FIPS 140-3:** Using a cryptographic library or AES implementation does not make an application FIPS validated. Validation applies to a specific cryptographic module, version, configuration, and operating environment listed by the relevant program.
- **BitLocker:** This package checks status; it does not manage recovery keys or silently turn encryption on. Confirm recovery-key backup and organizational policy before enabling encryption.
- **iOS biometrics:** LocalAuthentication gives the app a local success/failure result. A server cannot verify the truth of a client-supplied boolean. Production authorization needs a cryptographic, server-verifiable proof tied to the exact request.
- **Testing:** Nine passing tests only indicate that those assertions passed in that environment. They are not a penetration test, audit opinion, security certification, or guarantee of absence of vulnerabilities.
