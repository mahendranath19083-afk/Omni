# OMNI Sentinel — Architecture Specification

## Purpose
A local-first workstation security companion that reports host posture, records security-relevant approvals, and exposes a minimal API. The default trust boundary is the local machine; remote access is disabled by default.

## Components
- **Windows hardening script:** checks elevation; observes BitLocker and Microsoft Defender; configures a firewall baseline; enables logon and process creation audit categories; optionally registers a limited-user startup task.
- **FastAPI backend:** binds to loopback; API-key protects privileged routes; host posture reports unknown when probes fail; SQLite stores ticket status, hashed session tokens, and a small audit trail.
- **Approval workflow:** ticket is scoped to action/resource/requester/reason, expires after 120 seconds, and has one terminal status. Approval requires a biometric confirmation signal from the companion. This signal is not cryptographically attested in the starter and must not be treated as sufficient proof for production elevation.
- **iOS companion:** Keychain item uses `AfterFirstUnlockThisDeviceOnly`; LocalAuthentication gates approval and emergency revocation; HTTP errors are checked.
- **AI tools:** allowlist is explicit and read-only; unknown tools are denied. No arbitrary shell, file deletion, surveillance, or remote execution tools exist.

## Security principles
1. Default deny and least privilege.
2. Keep the API loopback-bound unless a separate, reviewed gateway is introduced.
3. Never put secrets in source control, notifications, or logs.
4. Treat host posture as telemetry, not as proof of a secure host.
5. Treat biometric success on a client as local user authentication, not server-verifiable attestation.
6. Use short-lived, resource-scoped, one-time approval tickets.
7. Make high-impact actions require a cryptographically verifiable challenge/response and independent policy checks.
8. Remote audio/video and location functions are out of scope unless separately permissioned, visibly indicated, and explicitly authorized.

## Planned production hardening
- Replace API-key-only access with per-device identities, TLS, rotation, revocation, and challenge-response.
- Implement Apple App Attest or equivalent signed nonce bound to ticket ID, action, resource, expiry, and server origin.
- Implement FIDO2/WebAuthn and Windows Hello verification rather than placeholder assertions.
- Add Windows event log collection with explicit event sources, retention, and tamper-aware forwarding.
- Add rate limits, structured redacted logs, request IDs, database migration strategy, backups, and concurrency tests.
- Add signed releases, dependency pinning/lockfiles, SBOM, CI, threat modeling, and independent penetration testing.
